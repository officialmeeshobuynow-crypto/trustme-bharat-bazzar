package com.example.model

enum class MessageSender {
    USER,
    ASSISTANT,
    SYSTEM
}

sealed class MessageAction {
    data class ProductList(
        val products: List<Product>,
        val title: String = "Recommended Products"
    ) : MessageAction()

    data class ProductDetail(
        val product: Product
    ) : MessageAction()

    data class CartSummary(
        val items: List<CartItem>,
        val subtotal: Double,
        val discount: Double,
        val total: Double,
        val couponApplied: String? = null
    ) : MessageAction()

    data class OrderConfirmation(
        val order: Order
    ) : MessageAction()

    data class ProductComparison(
        val products: List<Product>
    ) : MessageAction()

    data class QuickSuggestions(
        val suggestions: List<String>
    ) : MessageAction()
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isVoiceInput: Boolean = false,
    val action: MessageAction? = null,
    val isSpeaking: Boolean = false
)

enum class VoiceState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING
}

enum class AssistantLanguage(val code: String, val displayName: String, val speechLocaleCode: String) {
    HINGLISH("hinglish", "Hinglish (हिंदी + Eng)", "hi-IN"),
    HINDI("hi", "हिन्दी (Hindi)", "hi-IN"),
    ENGLISH("en", "English", "en-US")
}
