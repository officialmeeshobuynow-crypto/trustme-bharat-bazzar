package com.example.model

data class Product(
    val id: String,
    val name: String,
    val hindiName: String = "",
    val category: String,
    val subCategory: String = "",
    val city: String = "Barbigha",
    val vertical: String = "TRUST ME भारत-BAZAAR",
    val price: Double,
    val originalPrice: Double,
    val rating: Float = 4.8f,
    val reviewsCount: Int = 120,
    val inStock: Boolean = true,
    val drawableRes: Int = 0,
    val description: String,
    val hindiDescription: String = "",
    val features: List<String> = emptyList(),
    val deliveryEstimate: String = "Delivery in 24-48 Hours",
    val tags: List<String> = emptyList(),
    val isBestSeller: Boolean = false,
    val isDealOfTheDay: Boolean = false
) {
    val discountPercent: Int
        get() = if (originalPrice > price) {
            (((originalPrice - price) / originalPrice) * 100).toInt()
        } else 0

    val formattedPrice: String
        get() = "₹${String.format("%,.0f", price)}"

    val formattedOriginalPrice: String
        get() = "₹${String.format("%,.0f", originalPrice)}"
}

data class CartItem(
    val product: Product,
    val quantity: Int = 1,
    val selectedOption: String = ""
) {
    val totalPrice: Double
        get() = product.price * quantity

    val formattedTotalPrice: String
        get() = "₹${String.format("%,.0f", totalPrice)}"
}

enum class OrderStatus(val label: String, val hindiLabel: String, val stepIndex: Int) {
    PLACED("Order Placed", "ऑर्डर स्वीकार हुआ", 0),
    PROCESSING("Preparing & Packed", "पैकिंग हो रही है", 1),
    SHIPPED("Shipped", "शिप हो गया", 2),
    OUT_FOR_DELIVERY("Out for Delivery", "डिलीवरी के लिए निकल चुका है", 3),
    DELIVERED("Delivered", "डिलीवर हो गया", 4)
}

data class Order(
    val orderId: String,
    val items: List<CartItem>,
    val subtotal: Double,
    val discount: Double,
    val deliveryFee: Double,
    val total: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val status: OrderStatus = OrderStatus.PLACED,
    val deliveryAddress: String = "Flat 402, Green Valley Apts, Bangalore 560034",
    val paymentMethod: String = "Cash on Delivery / UPI",
    val estimatedDeliveryDate: String = "Within 48 Hours"
) {
    val formattedTotal: String
        get() = "₹${String.format("%,.0f", total)}"

    val formattedDiscount: String
        get() = "₹${String.format("%,.0f", discount)}"
}
