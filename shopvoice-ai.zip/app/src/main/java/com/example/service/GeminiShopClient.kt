package com.example.service

import android.util.Log
import com.example.BuildConfig
import com.example.data.CartAndOrderRepository
import com.example.data.ProductCatalog
import com.example.model.ChatMessage
import com.example.model.MessageAction
import com.example.model.MessageSender
import com.example.model.Product
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AIResponse(
    val spokenText: String,
    val action: MessageAction? = null
)

object GeminiShopClient {

    private const val TAG = "GeminiShopClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val systemPrompt: String
        get() {
            val catalogSummary = ProductCatalog.products.joinToString("\n") { p ->
                "- ID: ${p.id} | Name: ${p.name} | City: ${p.city} | Vertical: ${p.vertical} | Category: ${p.category} | Price: ₹${p.price.toInt()} (MRP: ₹${p.originalPrice.toInt()}) | Rating: ${p.rating}★ | Features: ${p.features.joinToString(", ")}"
            }

            return """
You are the official AI Voice Assistant for "THE-इन्सानियत PVT.LTD" and "TRUST ME भारत-BAZAAR".
You represent a comprehensive business ecosystem across 4 Digital Bazaar cities (Barbigha, Sarmera, Sheikhpura, Bihar Sharif) spanning 37 categories, along with:
1. TRUST ME भारत-BAZAAR (Barbigha, Sarmera, Sheikhpura, Bihar Sharif - 37 Categories: Food & Grocery, Health & Medical, Government & Utilities, Banking & FinTech, Agriculture, Wedding & Events, Religious, Beauty, Automobile, Home & Living, Fashion, Footwear, Jewellery, Electronics, Logistics, Repair & Maintenance, etc.)
2. Social Media Agency (Camera Man for Shorts/Reels, Video Editor Expert for Ads/UGC/Tech/Comedy, YT Account Manager)
3. School & Tuition — the इंसानियत गुरुकुल (Nursery 3-4 yrs, LKG, UKG, 1st Class with holistic parents routine & subjects)
4. Rapido-style business model — TWGB (Two-Wheeler Bike Taxi & Hyperlocal Express Parcel Delivery)
5. true jivansathi.com (100% Aadhaar Verified Matrimony & Matchmaking)
6. Farming & Dairy (Livestock & Produce: Pure Cow Milk, Shuddh Desi Ghee, Organic Honey, Eggs, Fish, Chicken, Fruits)
7. Affiliate Marketing Experts Group & Instagram High-Paying Theme Pages
8. YouTube Channel-as-a-Shop (Turnkey studio + Storyteller on salary)
9. All 107 Products & 107 Factories of THE-इन्सानियत (Direct factory wholesale supply)

CURRENT PRODUCT & SERVICE CATALOG:
$catalogSummary

SPECIAL PROMO CODES:
- 'INSANIYAT20': 20% OFF on all products & services
- 'WELCOME500': ₹500 flat discount
- 'FREESHIP': Free express delivery across Barbigha, Sarmera, Sheikhpura & Bihar Sharif

YOUR INSTRUCTIONS:
1. Respond in a warm, respectful, conversational Hindi/Hinglish/English voice. Be polite (use "Namaste", "Aapka swagat hai").
2. Embed EXACTLY ONE ACTION TAG in your response if the user wants to view products, search categories/cities, add to cart, track orders, or checkout:
   - [ACTION:SEARCH query="keyword" city="city" vertical="vert" category="cat" maxPrice="num"]
   - [ACTION:SHOW_PRODUCT id="product_id"]
   - [ACTION:ADD_TO_CART id="product_id" qty="1"]
   - [ACTION:REMOVE_FROM_CART id="product_id"]
   - [ACTION:VIEW_CART]
   - [ACTION:APPLY_COUPON code="code"]
   - [ACTION:CHECKOUT]
   - [ACTION:TRACK_ORDER id="order_id"]
   - [ACTION:SHOW_DEALS]

Example:
User: "Barbigha me shuddh desi ghee chahiye"
Response: "THE-इन्सानियत का 100% शुद्ध बिलोना गाय का घी बरबीघा में सेम-डे डिलीवरी पर उपलब्ध है, सिर्फ ₹680 में! [ACTION:SEARCH query="ghee" city="Barbigha"]"
            """.trimIndent()
        }

    suspend fun processUserQuery(
        query: String,
        conversationHistory: List<ChatMessage>
    ): AIResponse = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey.equals("MY_GEMINI_API_KEY", ignoreCase = true)) {
            return@withContext processWithLocalEngine(query)
        }

        try {
            val jsonBody = JSONObject().apply {
                val contentsArray = JSONArray()

                val recentHistory = conversationHistory.takeLast(4)
                for (msg in recentHistory) {
                    val role = if (msg.sender == MessageSender.USER) "user" else "model"
                    contentsArray.put(JSONObject().apply {
                        put("role", role)
                        put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                    })
                }

                contentsArray.put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", query)))
                })
                put("contents", contentsArray)

                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
                })

                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.6)
                    put("topP", 0.95)
                })
            }

            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errorBody = response.body?.string()
                Log.w(TAG, "Gemini API error: $errorBody. Using local engine.")
                return@withContext processWithLocalEngine(query)
            }

            val responseString = response.body?.string() ?: ""
            val jsonResponse = JSONObject(responseString)
            val candidates = jsonResponse.optJSONArray("candidates")
            val candidate = candidates?.optJSONObject(0)
            val content = candidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val rawText = parts?.optJSONObject(0)?.optString("text") ?: ""

            if (rawText.isBlank()) {
                return@withContext processWithLocalEngine(query)
            }

            parseResponseWithActions(rawText, query)
        } catch (e: Exception) {
            Log.e(TAG, "Error calling Gemini API, fallback to local engine", e)
            processWithLocalEngine(query)
        }
    }

    private fun parseResponseWithActions(rawText: String, userQuery: String): AIResponse {
        val actionRegex = Regex("\\[ACTION:([A-Z_]+)(.*?)\\]")
        val match = actionRegex.find(rawText)

        val cleanSpeech = rawText.replace(actionRegex, "").trim()

        if (match == null) {
            return AIResponse(spokenText = cleanSpeech)
        }

        val actionName = match.groupValues[1]
        val paramsString = match.groupValues[2]
        val params = parseParams(paramsString)

        val messageAction: MessageAction? = when (actionName) {
            "SEARCH" -> {
                val q = params["query"] ?: ""
                val cat = params["category"]
                val city = params["city"]
                val vert = params["vertical"]
                val maxPrice = params["maxPrice"]?.toDoubleOrNull()
                val found = ProductCatalog.searchProducts(
                    query = q,
                    category = cat,
                    city = city,
                    vertical = vert,
                    maxPrice = maxPrice
                )
                MessageAction.ProductList(
                    products = if (found.isNotEmpty()) found else ProductCatalog.products.take(4),
                    title = if (q.isNotBlank()) "Search Results for '$q'" else "Top Recommendations"
                )
            }
            "SHOW_PRODUCT" -> {
                val id = params["id"] ?: ""
                val product = ProductCatalog.findById(id) ?: ProductCatalog.products.first()
                MessageAction.ProductDetail(product)
            }
            "ADD_TO_CART" -> {
                val id = params["id"] ?: ""
                val qty = params["qty"]?.toIntOrNull() ?: 1
                val product = ProductCatalog.findById(id) ?: ProductCatalog.products.first()
                CartAndOrderRepository.addToCart(product, qty)
                val cart = CartAndOrderRepository.cartState.value
                MessageAction.CartSummary(
                    items = cart.items,
                    subtotal = cart.subtotal,
                    discount = cart.couponDiscount,
                    total = cart.total,
                    couponApplied = cart.appliedCoupon
                )
            }
            "REMOVE_FROM_CART" -> {
                val id = params["id"] ?: ""
                CartAndOrderRepository.removeFromCart(id)
                val cart = CartAndOrderRepository.cartState.value
                MessageAction.CartSummary(
                    items = cart.items,
                    subtotal = cart.subtotal,
                    discount = cart.couponDiscount,
                    total = cart.total,
                    couponApplied = cart.appliedCoupon
                )
            }
            "VIEW_CART" -> {
                val cart = CartAndOrderRepository.cartState.value
                MessageAction.CartSummary(
                    items = cart.items,
                    subtotal = cart.subtotal,
                    discount = cart.couponDiscount,
                    total = cart.total,
                    couponApplied = cart.appliedCoupon
                )
            }
            "APPLY_COUPON" -> {
                val code = params["code"] ?: "INSANIYAT20"
                CartAndOrderRepository.applyCoupon(code)
                val cart = CartAndOrderRepository.cartState.value
                MessageAction.CartSummary(
                    items = cart.items,
                    subtotal = cart.subtotal,
                    discount = cart.couponDiscount,
                    total = cart.total,
                    couponApplied = cart.appliedCoupon
                )
            }
            "CHECKOUT" -> {
                val order = CartAndOrderRepository.placeOrder()
                if (order != null) {
                    MessageAction.OrderConfirmation(order)
                } else {
                    val cart = CartAndOrderRepository.cartState.value
                    MessageAction.CartSummary(cart.items, cart.subtotal, cart.couponDiscount, cart.total)
                }
            }
            "TRACK_ORDER" -> {
                val id = params["id"] ?: ""
                val order = CartAndOrderRepository.getOrderById(id)
                if (order != null) MessageAction.OrderConfirmation(order) else null
            }
            "SHOW_DEALS" -> {
                MessageAction.ProductList(ProductCatalog.getDeals(), "Today's Best Deals ⚡")
            }
            else -> null
        }

        return AIResponse(spokenText = cleanSpeech, action = messageAction)
    }

    private fun parseParams(paramString: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        val regex = Regex("(\\w+)=\"([^\"]*)\"")
        regex.findAll(paramString).forEach { match ->
            map[match.groupValues[1]] = match.groupValues[2]
        }
        return map
    }

    fun processWithLocalEngine(rawQuery: String): AIResponse {
        val q = rawQuery.lowercase().trim()

        // 1. Check Cart
        if (q.contains("cart") && (q.contains("dikhao") || q.contains("show") || q.contains("kya hai") || q.contains("view") || q.contains("check") || q.contains("kitna"))) {
            val cart = CartAndOrderRepository.cartState.value
            return if (cart.items.isEmpty()) {
                AIResponse(
                    spokenText = "Aapka cart abhi khali hai. THE-इन्सानियत ke shuddh utpaad ya services add karein!",
                    action = MessageAction.ProductList(ProductCatalog.getDeals(), "Popular Offerings 🔥")
                )
            } else {
                AIResponse(
                    spokenText = "Aapke cart me ${cart.totalItemCount} items hain aur total bill ${cart.formattedTotal} hai.",
                    action = MessageAction.CartSummary(cart.items, cart.subtotal, cart.couponDiscount, cart.total, cart.appliedCoupon)
                )
            }
        }

        // 2. Checkout / Order
        if (q.contains("checkout") || q.contains("order place") || q.contains("order kar do") || q.contains("buy now") || q.contains("kharid lo") || q.contains("payment")) {
            val cart = CartAndOrderRepository.cartState.value
            if (cart.items.isEmpty()) {
                return AIResponse(
                    spokenText = "Cart me pehle product ya service select karein fir turant order confirm karte hain!",
                    action = MessageAction.ProductList(ProductCatalog.getDeals(), "Trending Offerings ⚡")
                )
            }
            val order = CartAndOrderRepository.placeOrder(deliveryAddress = "Barbigha, Sheikhpura")
            return if (order != null) {
                AIResponse(
                    spokenText = "Aapka order ${order.orderId} safalta-purvak place ho gaya hai! Total amount ${order.formattedTotal} hai.",
                    action = MessageAction.OrderConfirmation(order)
                )
            } else {
                AIResponse(spokenText = "Order place karne me samasya aayi. Kripya punah prayas karein.")
            }
        }

        // 3. Track Order
        if (q.contains("track") || q.contains("order kahan") || q.contains("order status") || q.contains("delivery kab") || q.contains("kahan pahucha")) {
            val orders = CartAndOrderRepository.orders.value
            val latest = orders.firstOrNull()
            return if (latest != null) {
                AIResponse(
                    spokenText = "Aapka order ${latest.orderId} ${latest.status.hindiLabel} hai aur ${latest.estimatedDeliveryDate} deliver hoga!",
                    action = MessageAction.OrderConfirmation(latest)
                )
            } else {
                AIResponse(spokenText = "Abhi koi active order nahi mila. Aap nayi shopping shuru kar sakte hain!")
            }
        }

        // 4. Coupons
        if (q.contains("coupon") || q.contains("discount") || q.contains("offer code") || q.contains("promo") || q.contains("chhoot")) {
            val result = CartAndOrderRepository.applyCoupon("VOICE20")
            val cart = CartAndOrderRepository.cartState.value
            return AIResponse(
                spokenText = result.second,
                action = MessageAction.CartSummary(cart.items, cart.subtotal, cart.couponDiscount, cart.total, cart.appliedCoupon)
            )
        }

        // 5. School & Tuition - इंसानियत गुरुकुल
        if (q.contains("gurukul") || q.contains("school") || q.contains("nursery") || q.contains("tuition") || q.contains("bachho") || q.contains("lkg") || q.contains("ukg") || q.contains("padhai")) {
            val gurukulProducts = ProductCatalog.products.filter { it.vertical.contains("गुरुकुल") }
            return AIResponse(
                spokenText = "the इंसानियत गुरुकुल me Nursery se 1st Class tak ke bacchon ke liye sanskaryukt daily routine aur comprehensive study program available hai!",
                action = MessageAction.ProductList(gurukulProducts, "the इंसानियत गुरुकुल Programs 📚")
            )
        }

        // 6. TWGB Bike Taxi & Rapido
        if (q.contains("twgb") || q.contains("bike taxi") || q.contains("rapido") || q.contains("ride") || q.contains("parcel") || q.contains("courier") || q.contains("travel")) {
            val twgbProducts = ProductCatalog.products.filter { it.vertical.contains("TWGB") }
            return AIResponse(
                spokenText = "TWGB Bike Taxi aur Hyperlocal Parcel service Barbigha aur aas-paas ke ilakon me 3-5 minute me doorstep pickup ke saath shuru hai!",
                action = MessageAction.ProductList(twgbProducts, "TWGB Bike Taxi & Express Logistics 🏍️")
            )
        }

        // 7. Social Media Agency (Video Editor, Cameraman, YT)
        if (q.contains("camera") || q.contains("video") || q.contains("editor") || q.contains("shorts") || q.contains("reels") || q.contains("youtube") || q.contains("agency") || q.contains("channel")) {
            val agencyProducts = ProductCatalog.products.filter { it.vertical.contains("Social Media") || it.vertical.contains("YouTube") || it.vertical.contains("Instagram") }
            return AIResponse(
                spokenText = "Social Media Agency ke tahat Shorts Camera Man, Ads Video Editor aur YouTube Channel-as-a-Shop setup uplabdh hai!",
                action = MessageAction.ProductList(agencyProducts, "Social Media & Video Production Services 🎬")
            )
        }

        // 8. Farming, Milk, Ghee & Produce
        if (q.contains("ghee") || q.contains("milk") || q.contains("doodh") || q.contains("honey") || q.contains("egg") || q.contains("chicken") || q.contains("fish") || q.contains("farming") || q.contains("shuddh")) {
            val farmProducts = ProductCatalog.products.filter { it.vertical == "Farming" || it.tags.contains("ghee") || it.tags.contains("dairy") }
            return AIResponse(
                spokenText = "THE-इन्सानियत फार्मिंग से 100% शुद्ध बिलोना गाय का घी, ताज़ा कच्चा दूध, शहद एवं देसी अंडे सीधे खेतों से उपलब्ध हैं!",
                action = MessageAction.ProductList(farmProducts, "Pure Farming & Dairy Produce 🥛")
            )
        }

        // 9. 107 Products & 107 Factories
        if (q.contains("107") || q.contains("factory") || q.contains("factories") || q.contains("wholesale") || q.contains("karkhana")) {
            val factoryProducts = ProductCatalog.products.filter { it.vertical.contains("107") }
            return AIResponse(
                spokenText = "THE-इन्सानियत की 107 फैक्ट्रियों से सीधे उत्पाद बिना बिचौलिये के होलसेल दरों पर उपलब्ध हैं!",
                action = MessageAction.ProductList(factoryProducts, "107 Products & 107 Factories 🏭")
            )
        }

        // 10. Matrimony / Rishte
        if (q.contains("matrimony") || q.contains("shadi") || q.contains("vivah") || q.contains("rishte") || q.contains("jivansathi")) {
            val matrimony = ProductCatalog.products.filter { it.vertical.contains("jivansathi") }
            return AIResponse(
                spokenText = "true jivansathi.com par 100% आधार एवं परिवार सत्यापित वैवाहिक रिश्ते उपलब्ध हैं!",
                action = MessageAction.ProductList(matrimony, "true jivansathi.com (Matrimony) 💍")
            )
        }

        // 11. Specific City Searches (Barbigha, Sarmera, Sheikhpura, Bihar Sharif)
        val matchedCity = when {
            q.contains("barbigha") || q.contains("बरबीघा") -> "Barbigha"
            q.contains("sarmera") || q.contains("सरमेरा") -> "Sarmera"
            q.contains("sheikhpura") || q.contains("शेखपुरा") -> "Sheikhpura"
            q.contains("bihar sharif") || q.contains("बिहार शरीफ") -> "Bihar Sharif"
            else -> null
        }

        // 12. General Product/Category Search
        val searchResults = ProductCatalog.searchProducts(
            query = q.replace("dikhao", "").replace("chahiye", "").replace("show", "").replace("kahan hai", "").trim(),
            city = matchedCity
        )

        return if (searchResults.isNotEmpty()) {
            val first = searchResults.first()
            AIResponse(
                spokenText = "Ye rahe aapke liye THE-इन्सानियत एवं TRUST ME भारत-BAZAAR ke best results, jaise ${first.name} sirf ${first.formattedPrice} me!",
                action = MessageAction.ProductList(searchResults, "Results for: $rawQuery")
            )
        } else {
            AIResponse(
                spokenText = "THE-इन्सानियत PVT.LTD ke sabhi 37 Digital Bazaar categories aur services me se trending picks ye rahe:",
                action = MessageAction.ProductList(ProductCatalog.getDeals(), "TRUST ME भारत-BAZAAR Top Picks 🌟")
            )
        }
    }
}
