package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VoiceState
import com.example.ui.theme.VoiceAccent
import com.example.ui.theme.VoiceCyan
import com.example.ui.theme.VoicePrimary
import com.example.ui.theme.WaveColor4

@Composable
fun VoiceWaveformVisualizer(
    voiceState: VoiceState,
    soundLevel: Float,
    partialTranscript: String,
    modifier: Modifier = Modifier
) {
    if (voiceState == VoiceState.IDLE) return

    val infiniteTransition = rememberInfiniteTransition(label = "waveTransition")
    val waveAnim1 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w1"
    )
    val waveAnim2 by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(550, delayMillis = 100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w2"
    )
    val waveAnim3 by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(350, delayMillis = 150, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w3"
    )

    val isListening = voiceState == VoiceState.LISTENING
    val isSpeaking = voiceState == VoiceState.SPEAKING
    val isProcessing = voiceState == VoiceState.PROCESSING

    val bgGradient = Brush.horizontalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
        )
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(bgGradient)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left Status / Live text
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val statusText = when {
                    isListening && partialTranscript.isNotBlank() -> "\"$partialTranscript\""
                    isListening -> "Listening... (Bolna shuru karein)"
                    isProcessing -> "AI soch raha hai... 🧠"
                    isSpeaking -> "Speaking response... 🔊"
                    else -> ""
                }

                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (partialTranscript.isNotBlank()) FontWeight.SemiBold else FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontSize = 13.sp
                    ),
                    maxLines = 2
                )
            }

            // Right animated wave bars
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.height(28.dp)
            ) {
                val barHeights = if (isListening) {
                    val boosted = (soundLevel * 1.5f).coerceIn(0.1f, 1f)
                    listOf(
                        10.dp + (24.dp * (boosted * waveAnim1)),
                        8.dp + (26.dp * (boosted * waveAnim2)),
                        12.dp + (28.dp * (boosted * waveAnim3)),
                        8.dp + (24.dp * (boosted * waveAnim1)),
                        10.dp + (22.dp * (boosted * waveAnim2))
                    )
                } else if (isSpeaking) {
                    listOf(
                        8.dp + (20.dp * waveAnim1),
                        12.dp + (24.dp * waveAnim2),
                        16.dp + (28.dp * waveAnim3),
                        10.dp + (22.dp * waveAnim2),
                        6.dp + (18.dp * waveAnim1)
                    )
                } else {
                    listOf(10.dp, 16.dp, 22.dp, 14.dp, 8.dp)
                }

                val colors = listOf(VoicePrimary, VoiceCyan, VoiceAccent, WaveColor4, VoicePrimary)

                barHeights.forEachIndexed { index, height ->
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(height)
                            .clip(RoundedCornerShape(50))
                            .background(colors[index % colors.size])
                    )
                }
            }
        }
    }
}
