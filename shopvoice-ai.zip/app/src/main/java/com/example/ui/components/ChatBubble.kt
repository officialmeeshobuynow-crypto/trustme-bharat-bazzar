package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChatMessage
import com.example.model.MessageAction
import com.example.model.MessageSender
import com.example.model.Product
import com.example.ui.theme.VoiceAccent
import com.example.ui.theme.VoicePrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatBubble(
    message: ChatMessage,
    isSpeakingThis: Boolean,
    onSpeakClick: (ChatMessage) -> Unit,
    onAddToCart: (Product) -> Unit,
    onViewProductDetail: (Product) -> Unit,
    onOpenCart: () -> Unit,
    onCheckout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.sender == MessageSender.USER
    val timeFormatted = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(message.timestamp))

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("chat_bubble_${message.id}"),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        // Message header with avatar/sender info
        if (!isUser) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(bottom = 4.dp, start = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SmartToy,
                        contentDescription = "ShopVoice AI",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Text(
                    text = "ShopVoice AI",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 11.sp
                    )
                )
            }
        }

        // Text bubble
        Box(
            modifier = Modifier
                .clip(
                    RoundedCornerShape(
                        topStart = if (isUser) 18.dp else 4.dp,
                        topEnd = if (isUser) 4.dp else 18.dp,
                        bottomStart = 18.dp,
                        bottomEnd = 18.dp
                    )
                )
                .background(
                    if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer
                )
                .padding(horizontal = 15.dp, vertical = 11.dp)
        ) {
            Column {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onPrimaryContainer,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Footer row inside bubble: mic indicator, time, speech icon
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (message.isVoiceInput) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Spoken with voice",
                            tint = if (isUser) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                            modifier = Modifier.size(12.dp)
                        )
                    }

                    Text(
                        text = timeFormatted,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isUser) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.75f) else MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                            fontSize = 10.sp
                        )
                    )

                    if (!isUser) {
                        IconButton(
                            onClick = { onSpeakClick(message) },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(
                                imageVector = if (isSpeakingThis) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                contentDescription = "Play voice audio",
                                tint = if (isSpeakingThis) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // Action Attachments (Product Carousel, Cart Summary, Order Tracking, Comparison)
        if (message.action != null) {
            Spacer(modifier = Modifier.height(8.dp))

            when (val act = message.action) {
                is MessageAction.ProductList -> {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = act.title,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            items(act.products, key = { it.id }) { product ->
                                ProductCard(
                                    product = product,
                                    onAddToCart = onAddToCart,
                                    onViewDetail = onViewProductDetail
                                )
                            }
                        }
                    }
                }

                is MessageAction.ProductDetail -> {
                    ProductCard(
                        product = act.product,
                        onAddToCart = onAddToCart,
                        onViewDetail = onViewProductDetail,
                        modifier = Modifier.fillMaxWidth(0.85f)
                    )
                }

                is MessageAction.CartSummary -> {
                    CartSummaryCard(
                        items = act.items,
                        subtotal = act.subtotal,
                        discount = act.discount,
                        total = act.total,
                        couponApplied = act.couponApplied,
                        onOpenCart = onOpenCart,
                        onCheckout = onCheckout
                    )
                }

                is MessageAction.OrderConfirmation -> {
                    OrderTrackingCard(
                        order = act.order
                    )
                }

                is MessageAction.ProductComparison -> {
                    ProductComparisonCard(
                        products = act.products,
                        onAddToCart = onAddToCart
                    )
                }

                is MessageAction.QuickSuggestions -> {
                    // Render chips
                }
                null -> {
                    // No action
                }
            }
        }
    }
}
