package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Natural Tones Design Theme Palette
val NaturalPrimary = Color(0xFF6750A4) // Refined Deep Purple / Natural Tones
val NaturalPrimaryContainer = Color(0xFFEADDFF)
val NaturalOnPrimaryContainer = Color(0xFF21005D)

val NaturalSecondary = Color(0xFF625B71)
val NaturalSecondaryContainer = Color(0xFFE8DEF8)
val NaturalOnSecondaryContainer = Color(0xFF1D192B)

val NaturalTertiary = Color(0xFF7D5260)
val NaturalTertiaryContainer = Color(0xFFFFD8E4)
val NaturalOnTertiaryContainer = Color(0xFF31111D)

val NaturalAccent = Color(0xFF6750A4)
val NaturalAccentWarm = Color(0xFF9C4146)
val NaturalEmerald = Color(0xFF2E7D32) // Success / In Stock / Online Green (e.g. 22C55E / 2E7D32)
val NaturalOnlineGreen = Color(0xFF22C55E)
val NaturalError = Color(0xFFB3261E) // Error / Recording Alert Red

// Light Theme Palettes (Natural Tones)
val LightBackground = Color(0xFFFDF8FD)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF3EDF7)
val LightOnSurface = Color(0xFF1D1B20)
val LightOnSurfaceVariant = Color(0xFF49454F)
val LightOutline = Color(0xFFCAC4D0)
val LightOutlineVariant = Color(0xFFD0BCFF)

// Dark Theme Palettes (Natural Tones)
val DarkBackground = Color(0xFF141218)
val DarkSurface = Color(0xFF1D1B20)
val DarkSurfaceVariant = Color(0xFF49454F)
val DarkOnSurface = Color(0xFFE6E1E5)
val DarkOnSurfaceVariant = Color(0xFFCAC4D0)
val DarkOutline = Color(0xFF938F99)

// Audio Wave Visualizer Colors (Natural Tones harmonic progression)
val WaveColor1 = Color(0xFF6750A4)
val WaveColor2 = Color(0xFF7D5260)
val WaveColor3 = Color(0xFF625B71)
val WaveColor4 = Color(0xFF9A82DB)

// Voice / Shopping aliases for compatibility
val VoicePrimary = NaturalPrimary
val VoicePrimaryDark = Color(0xFFD0BCFF)
val VoiceAccent = Color(0xFF7D5260)
val VoiceAccentBright = Color(0xFF6750A4)
val VoiceCyan = NaturalSecondary
val VoiceEmerald = NaturalOnlineGreen
val VoiceRose = NaturalTertiary


