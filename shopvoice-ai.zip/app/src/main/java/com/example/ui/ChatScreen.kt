package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.VoiceState
import com.example.ui.components.CartBottomSheet
import com.example.ui.components.CatalogBottomSheet
import com.example.ui.components.ChatBubble
import com.example.ui.components.OrdersBottomSheet
import com.example.ui.components.ProductDetailBottomSheet
import com.example.ui.components.QuickSuggestionChips
import com.example.ui.components.SettingsBottomSheet
import com.example.ui.components.VoiceWaveformVisualizer
import com.example.ui.theme.VoiceAccent
import com.example.ui.theme.VoiceCyan
import com.example.ui.theme.VoiceEmerald
import com.example.ui.theme.VoicePrimary
import com.example.viewmodel.VoiceShopViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: VoiceShopViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val messages by viewModel.messages.collectAsState()
    val cartState by viewModel.cartState.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val voiceState by viewModel.voiceState.collectAsState()
    val soundLevel by viewModel.soundLevel.collectAsState()
    val partialTranscript by viewModel.partialTranscript.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val isAutoTtsEnabled by viewModel.isAutoTtsEnabled.collectAsState()
    val activeProductDetail by viewModel.activeProductDetail.collectAsState()
    val isCartOpen by viewModel.isCartOpen.collectAsState()
    val isOrdersOpen by viewModel.isOrdersOpen.collectAsState()
    val isCatalogOpen by viewModel.isCatalogOpen.collectAsState()
    val isSettingsOpen by viewModel.isSettingsOpen.collectAsState()
    val infoBanner by viewModel.infoBannerMessage.collectAsState()

    var textInput by remember { mutableStateOf("") }

    // Permission launcher for microphone recording
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startListening()
        }
    }

    fun handleMicClick() {
        if (voiceState == VoiceState.LISTENING) {
            viewModel.stopListening()
            return
        }
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            viewModel.startListening()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Auto scroll down when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "ShopVoice AI",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 16.sp
                                    )
                                )
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(VoiceEmerald)
                                )
                            }
                            Text(
                                text = "Voice Assistant • ${selectedLanguage.displayName.substringBefore(" ")}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                },
                actions = {
                    // Catalog Button
                    IconButton(
                        onClick = { viewModel.setCatalogOpen(true) },
                        modifier = Modifier.testTag("btn_top_catalog")
                    ) {
                        Icon(imageVector = Icons.Default.GridView, contentDescription = "Catalog")
                    }

                    // Orders Button
                    IconButton(
                        onClick = { viewModel.setOrdersOpen(true) },
                        modifier = Modifier.testTag("btn_top_orders")
                    ) {
                        Icon(imageVector = Icons.Default.Inventory, contentDescription = "Orders")
                    }

                    // Cart Button with Badge
                    IconButton(
                        onClick = { viewModel.setCartOpen(true) },
                        modifier = Modifier.testTag("btn_top_cart")
                    ) {
                        BadgedBox(
                            badge = {
                                if (cartState.totalItemCount > 0) {
                                    Badge(
                                        containerColor = VoiceAccent,
                                        contentColor = Color.White
                                    ) {
                                        Text("${cartState.totalItemCount}")
                                    }
                                }
                            }
                        ) {
                            Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = "Cart")
                        }
                    }

                    // Settings Button
                    IconButton(
                        onClick = { viewModel.setSettingsOpen(true) },
                        modifier = Modifier.testTag("btn_top_settings")
                    ) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
                .navigationBarsPadding()
        ) {
            // Notification / Info Banner
            AnimatedVisibility(
                visible = infoBanner != null,
                enter = slideInVertically() + fadeIn(),
                exit = slideOutVertically() + fadeOut()
            ) {
                infoBanner?.let { msg ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(VoicePrimary.copy(alpha = 0.9f))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = msg,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.dismissBanner() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Chat Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatBubble(
                        message = message,
                        isSpeakingThis = isSpeaking,
                        onSpeakClick = { viewModel.speakMessage(it) },
                        onAddToCart = { viewModel.addToCart(it) },
                        onViewProductDetail = { viewModel.openProductDetail(it) },
                        onOpenCart = { viewModel.setCartOpen(true) },
                        onCheckout = {
                            viewModel.placeOrder()
                        }
                    )
                }
            }

            // Dynamic Voice Wave Visualizer Bar (when listening or speaking or processing)
            VoiceWaveformVisualizer(
                voiceState = voiceState,
                soundLevel = soundLevel,
                partialTranscript = partialTranscript
            )

            // Quick Shopping Prompt Chips
            QuickSuggestionChips(
                onSuggestionClick = { query ->
                    viewModel.processUserQuery(query, isVoiceInput = false)
                }
            )

            // Bottom Input Bar
            BottomVoiceInputBar(
                textInput = textInput,
                voiceState = voiceState,
                soundLevel = soundLevel,
                onTextChange = { textInput = it },
                onSend = {
                    if (textInput.isNotBlank()) {
                        viewModel.processUserQuery(textInput, isVoiceInput = false)
                        textInput = ""
                    }
                },
                onMicClick = { handleMicClick() }
            )
        }
    }

    // Modal Bottom Sheets
    if (isCartOpen) {
        CartBottomSheet(
            cartState = cartState,
            onDismiss = { viewModel.setCartOpen(false) },
            onUpdateQuantity = { id, qty -> viewModel.updateCartQuantity(id, qty) },
            onRemoveItem = { id -> viewModel.removeFromCart(id) },
            onApplyCoupon = { code -> viewModel.applyCoupon(code) },
            onPlaceOrder = { address ->
                viewModel.placeOrder(address)
            }
        )
    }

    activeProductDetail?.let { product ->
        ProductDetailBottomSheet(
            product = product,
            onDismiss = { viewModel.closeProductDetail() },
            onAddToCart = { viewModel.addToCart(it) },
            onBuyNow = {
                viewModel.addToCart(it)
                viewModel.setCartOpen(true)
            }
        )
    }

    if (isOrdersOpen) {
        OrdersBottomSheet(
            orders = orders,
            onDismiss = { viewModel.setOrdersOpen(false) }
        )
    }

    if (isCatalogOpen) {
        CatalogBottomSheet(
            onDismiss = { viewModel.setCatalogOpen(false) },
            onAddToCart = { viewModel.addToCart(it) },
            onViewDetail = { viewModel.openProductDetail(it) }
        )
    }

    if (isSettingsOpen) {
        SettingsBottomSheet(
            selectedLanguage = selectedLanguage,
            isAutoTtsEnabled = isAutoTtsEnabled,
            onLanguageChange = { viewModel.setLanguage(it) },
            onToggleAutoTts = { viewModel.toggleAutoTts() },
            onDismiss = { viewModel.setSettingsOpen(false) }
        )
    }
}

@Composable
fun BottomVoiceInputBar(
    textInput: String,
    voiceState: VoiceState,
    soundLevel: Float,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    onMicClick: () -> Unit
) {
    val isListening = voiceState == VoiceState.LISTENING

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Text Input Box
            OutlinedTextField(
                value = textInput,
                onValueChange = onTextChange,
                placeholder = {
                    Text(
                        text = if (isListening) "Listening... Bol rahe hain..." else "Type or tap mic to speak...",
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("chat_input_field"),
                shape = RoundedCornerShape(26.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                    focusedBorderColor = VoicePrimary
                ),
                singleLine = true,
                trailingIcon = {
                    if (textInput.isNotBlank()) {
                        IconButton(
                            onClick = onSend,
                            modifier = Modifier.testTag("btn_send_message")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send",
                                tint = VoicePrimary
                            )
                        }
                    }
                }
            )

            // Animated Mic Button
            Box(
                contentAlignment = Alignment.Center
            ) {
                // Pulsing ripple ring if listening
                if (isListening) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(VoiceAccent.copy(alpha = 0.3f))
                    )
                }

                FloatingActionButton(
                    onClick = onMicClick,
                    modifier = Modifier
                        .size(50.dp)
                        .testTag("btn_voice_mic"),
                    shape = CircleShape,
                    containerColor = if (isListening) VoiceAccent else VoicePrimary,
                    contentColor = Color.White
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = if (isListening) "Stop Listening" else "Start Voice Assistant",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}
