package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ChatScreen
import com.example.ui.theme.ShopVoiceTheme
import com.example.viewmodel.VoiceShopViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ShopVoiceTheme {
                val viewModel: VoiceShopViewModel = viewModel()
                ChatScreen(viewModel = viewModel)
            }
        }
    }
}

