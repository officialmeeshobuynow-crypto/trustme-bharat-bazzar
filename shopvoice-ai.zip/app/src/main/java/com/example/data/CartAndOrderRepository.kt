package com.example.data

import com.example.model.CartItem
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.Product
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class CartState(
    val items: List<CartItem> = emptyList(),
    val appliedCoupon: String? = null,
    val couponDiscount: Double = 0.0,
    val deliveryFee: Double = 0.0
) {
    val subtotal: Double
        get() = items.sumOf { it.totalPrice }

    val totalItemCount: Int
        get() = items.sumOf { it.quantity }

    val total: Double
        get() = (subtotal - couponDiscount + (if (subtotal > 0) deliveryFee else 0.0)).coerceAtLeast(0.0)

    val formattedSubtotal: String
        get() = "₹${String.format("%,.0f", subtotal)}"

    val formattedDiscount: String
        get() = "₹${String.format("%,.0f", couponDiscount)}"

    val formattedTotal: String
        get() = "₹${String.format("%,.0f", total)}"
}

object CartAndOrderRepository {
    private val _cartState = MutableStateFlow(CartState())
    val cartState: StateFlow<CartState> = _cartState.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(
        listOf(
            Order(
                orderId = "ORD-INS-108",
                items = listOf(
                    CartItem(
                        product = ProductCatalog.products[0],
                        quantity = 1
                    )
                ),
                subtotal = 680.0,
                discount = 136.0,
                deliveryFee = 0.0,
                total = 544.0,
                timestamp = System.currentTimeMillis() - 43200000L,
                status = OrderStatus.OUT_FOR_DELIVERY,
                deliveryAddress = "Main Road, Barbigha, Sheikhpura 811101",
                estimatedDeliveryDate = "Expected Today by 5 PM"
            )
        )
    )
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    fun addToCart(product: Product, quantity: Int = 1, option: String = ""): CartItem {
        val currentItems = _cartState.value.items.toMutableList()
        val existingIndex = currentItems.indexOfFirst { it.product.id == product.id && it.selectedOption == option }

        val updatedItem: CartItem
        if (existingIndex >= 0) {
            val existing = currentItems[existingIndex]
            updatedItem = existing.copy(quantity = existing.quantity + quantity)
            currentItems[existingIndex] = updatedItem
        } else {
            updatedItem = CartItem(product = product, quantity = quantity, selectedOption = option)
            currentItems.add(updatedItem)
        }

        recalculateCart(currentItems, _cartState.value.appliedCoupon)
        return updatedItem
    }

    fun removeFromCart(productId: String): Boolean {
        val currentItems = _cartState.value.items.toMutableList()
        val removed = currentItems.removeAll { it.product.id == productId }
        if (removed) {
            recalculateCart(currentItems, _cartState.value.appliedCoupon)
        }
        return removed
    }

    fun updateQuantity(productId: String, quantity: Int) {
        val currentItems = _cartState.value.items.toMutableList()
        val index = currentItems.indexOfFirst { it.product.id == productId }
        if (index >= 0) {
            if (quantity <= 0) {
                currentItems.removeAt(index)
            } else {
                currentItems[index] = currentItems[index].copy(quantity = quantity)
            }
            recalculateCart(currentItems, _cartState.value.appliedCoupon)
        }
    }

    fun clearCart() {
        _cartState.value = CartState()
    }

    fun applyCoupon(code: String): Pair<Boolean, String> {
        val normalizedCode = code.trim().uppercase()
        val subtotal = _cartState.value.subtotal

        if (subtotal <= 0) {
            return Pair(false, "Cart is empty. Add products before applying coupon.")
        }

        return when (normalizedCode) {
            "VOICE20", "VOICE20OFF" -> {
                val discount = subtotal * 0.20
                recalculateCart(_cartState.value.items, "VOICE20", discount)
                Pair(true, "Coupon VOICE20 applied! You saved 20% (₹${String.format("%,.0f", discount)}) 🎉")
            }
            "WELCOME500", "FIRST500" -> {
                val discount = 500.0.coerceAtMost(subtotal * 0.5)
                recalculateCart(_cartState.value.items, "WELCOME500", discount)
                Pair(true, "Coupon WELCOME500 applied! ₹500 flat discount added! 🎁")
            }
            "FREESHIP" -> {
                recalculateCart(_cartState.value.items, "FREESHIP", 0.0, 0.0)
                Pair(true, "Coupon FREESHIP applied! Free express delivery unlocked! 🚚")
            }
            else -> {
                Pair(false, "Invalid coupon code. Try 'VOICE20' for 20% off or 'WELCOME500'!")
            }
        }
    }

    fun removeCoupon() {
        recalculateCart(_cartState.value.items, null, 0.0)
    }

    private fun recalculateCart(
        items: List<CartItem>,
        coupon: String?,
        customDiscount: Double? = null,
        deliveryFee: Double = 0.0
    ) {
        val subtotal = items.sumOf { it.totalPrice }
        val discount = customDiscount ?: when (coupon) {
            "VOICE20" -> subtotal * 0.20
            "WELCOME500" -> 500.0.coerceAtMost(subtotal * 0.5)
            else -> 0.0
        }

        _cartState.value = CartState(
            items = items,
            appliedCoupon = coupon,
            couponDiscount = discount,
            deliveryFee = deliveryFee
        )
    }

    fun placeOrder(
        deliveryAddress: String = "Flat 402, Green Valley Apts, Bangalore 560034",
        paymentMethod: String = "Cash on Delivery / UPI"
    ): Order? {
        val currentState = _cartState.value
        if (currentState.items.isEmpty()) return null

        val randomId = "ORD-" + (10000..99999).random()
        val order = Order(
            orderId = randomId,
            items = currentState.items.toList(),
            subtotal = currentState.subtotal,
            discount = currentState.couponDiscount,
            deliveryFee = currentState.deliveryFee,
            total = currentState.total,
            timestamp = System.currentTimeMillis(),
            status = OrderStatus.PLACED,
            deliveryAddress = deliveryAddress,
            paymentMethod = paymentMethod,
            estimatedDeliveryDate = "Expected in 48 Hours"
        )

        val updatedOrders = _orders.value.toMutableList()
        updatedOrders.add(0, order)
        _orders.value = updatedOrders

        clearCart()
        return order
    }

    fun getOrderById(orderId: String): Order? {
        val clean = orderId.trim().uppercase()
        return _orders.value.find { it.orderId.uppercase().contains(clean) || clean.contains(it.orderId.uppercase()) }
            ?: _orders.value.firstOrNull()
    }
}
